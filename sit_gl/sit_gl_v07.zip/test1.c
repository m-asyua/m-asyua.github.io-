#include "sit.h"

void sit_main(){

	point( 50, 50,  5);

}

void KeyDown(unsigned char){
}
