#include "sit.h"

void sit_main(){


	imageBmp("test_24bit.bmp", 400, 50, 30,80);
	delay(1000);
        rect(400,  50, 430, 130,"white");

	imageBmp("test_24bit.bmp", 460, 50, 30,80);

}

void KeyDown(unsigned char key){

}